package br.com.lucas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchedulingJobApplicationTests {

	@Test
	void contextLoads() {
	}

}
