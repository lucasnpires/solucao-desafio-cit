package br.com.lucas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchedulingJobApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchedulingJobApplication.class, args);
	}

}
